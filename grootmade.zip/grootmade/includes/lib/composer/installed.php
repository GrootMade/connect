<?php return array(
    'root' => array(
        'name' => 'project/plugin',
        'pretty_version' => 'dev-main',
        'version' => 'dev-main',
        'reference' => '3c8a06ca83ee02a3335cfff4afd618e5ef30bffb',
        'type' => 'project',
        'install_path' => __DIR__ . '/../../../',
        'aliases' => array(),
        'dev' => true,
    ),
    'versions' => array(
        'project/plugin' => array(
            'pretty_version' => 'dev-main',
            'version' => 'dev-main',
            'reference' => '3c8a06ca83ee02a3335cfff4afd618e5ef30bffb',
            'type' => 'project',
            'install_path' => __DIR__ . '/../../../',
            'aliases' => array(),
            'dev_requirement' => false,
        ),
    ),
);
